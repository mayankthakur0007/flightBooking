import { html, PolymerElement } from '@polymer/polymer/polymer-element.js';

import '@polymer/paper-input/paper-input.js';
import '@polymer/iron-form/iron-form.js';
import '@polymer/app-route/app-location.js';
import '../../node_modules/@polymer/app-route/app-route.js';



/**
* @customElement
* @polymer
*/
class PassengerDetail extends PolymerElement {
  static get template() {
    return html`
<style>
  :host {
    display: block;
  }
#form {
    border: 1px solid black;
    width: 100%;
    
  }

  form {
    margin-left: 20px;
    margin-right: 20px;
  }

  h2 {
    text-align: center;
    word-spacing: 2px;
  }

  paper-button {
    text-align: center;
    margin-top: 40px;
    margin-bottom: 40px;
    margin-left: 180px;
  }

  paper-input{
    width: 100%;
    margin-right: 20px;
  }

  #pass{
    flex-direction: row;
    display: flex;
    flex: wrap;
  }
</style>
<h2> Enter passenger details</h2>
<app-location route={{route}}></app-location>

<div>


  <template is='dom-repeat' items={{passangerList}}>
  <h3> Passanger {{_getIndex(index)}} </h3>

  <form>
  
    <paper-input label=" Passenger Name" name="passagerName" class="passagerName"></paper-input>
    <paper-input label="Age" auto-validate pattern="[0-9]*" error-message="numbers only!" type="text" maxlength="2" name="age" class="age">
    </paper-input>
    <paper-input label="Adhaar Number" auto-validate pattern="[0-9]*" error-message="numbers only!" type="text" name="aadhar" class="aadhar" maxlength="16"></paper-input>
  
  </form>
  
  </template>

</div> 
<paper-button raised class="custom indigo" on-click="nextStep">Next Step</paper-button>
`;
  }
  static get properties() {
    return {
      number: {
        type: Array,
        value: sessionStorage.getItem("number")
      },
      pCount: {
        type: Number,
        value: this.pCount,
        observer: "_pCountChanged"
      },
      passangerList: {
        type: Array,
        value: []
      },
      passangerDetails: {
        type: Array,
        value: []
      }

    };
  }
  connectedCallback() {
    super.connectedCallback();

  }
  _pCountChanged(newVal, oldVal) {
    for (let count = 0; count < newVal; count++) {
      this.push('passangerList', newVal);
    }
  }
  nextStep() {
    let passangerNodes = this.shadowRoot.querySelectorAll('.passagerName');
    let ageNodes = this.shadowRoot.querySelectorAll('.age');
    let aadharNodes = this.shadowRoot.querySelectorAll('.aadhar');
    for (let i = 0; i < passangerNodes.length; i++) {
      this.push('passangerDetails', { passagerName: passangerNodes[i].value, age: parseInt(ageNodes[i].value), aadhar: parseInt(aadharNodes[i].value) })
    }

    this.set('route.path', './payment');

  }

  _getIndex(index) {
    return index + 1;
  }
}

window.customElements.define('passenger-detail', PassengerDetail);