import { html, PolymerElement } from '@polymer/polymer/polymer-element.js';
import '@polymer/paper-input/paper-input.js';
import '../../node_modules/@polymer/app-route/app-route.js';
import '@polymer/app-route/app-location.js';
import '../../node_modules/@polymer/paper-button/paper-button.js';
import '../../node_modules/@polymer/iron-ajax/iron-ajax.js';
/**
 * @customElement
 * @polymer
 */
class TrackJourney extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
      </style>
    <paper-input label="Booking Id" id="id" ></paper-input>
    <paper-button type="submit" id="btn" class="btn btn-success" on-click="_getData">Search</paper-button>
    <iron-ajax id="ajax" on-response="_handleResponse" handle-as="json" content-type='application/json'></iron-ajax>
    `;
  }
  static get properties() {
    return {
      details: {
        type: Array,
        value: []
      }, action: {
        type: String
      }
    };
  }
  connectedCallback() {
    super.connectedCallback();
  }

  /** getdata function for fetching the data from the database and showing it. Ajax request is done in pets
  
  for the data with sell property value "yes" only. This function is also called when any new pet is added 
  
  so that the list got again refreshed **/

  _getData() {
    let id = this.$.id.value;
    this._makeAjax(`http://10.117.189.181:8080/flightbooking/tickets/${id}`, "GET", null);
    this.action = 'List';
  }
  _makeAjax(url, method, postObj) {
    console.log(url, method, postObj)
    const ajax = this.$.ajax;
    ajax.method = method;
    ajax.url = url;
    ajax.body = postObj ? JSON.stringify(postObj) : undefined;
    ajax.generateRequest();
  }
  _handleResponse(event) {
    console.log(event.detail)
    switch (this.action) {

      case 'List':
        this.details = event.detail.response;
        console.log(this.details)
        break;
    }


  }
}

window.customElements.define('track-journey', TrackJourney);


