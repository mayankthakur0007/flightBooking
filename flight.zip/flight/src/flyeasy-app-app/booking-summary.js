import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/app-route/app-location.js';
import '../../node_modules/@polymer/app-route/app-route.js';

/**
 * @customElement
 * @polymer
 */
class BookingSummary extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
      </style>
      <h2>Hello [[prop1]]!</h2>
    `;
  }
  static get properties() {
    return {
      prop1: {
        type: String,
        value: 'booking summary details'
      }
    };
  }
}

window.customElements.define('booking-summary', BookingSummary);


