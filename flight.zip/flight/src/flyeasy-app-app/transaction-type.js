import { html, PolymerElement } from '@polymer/polymer/polymer-element.js';

import '@polymer/paper-radio-group/paper-radio-group.js';
import '@polymer/paper-radio-button/paper-radio-button.js';
import '@polymer/app-route/app-location.js';
import '../../node_modules/@polymer/app-route/app-route.js';

/**
 * @customElement
 * @polymer
 */
class TransactionType extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
      </style>
     
      <app-location route="{{route}}">
      </app-location>
      <app-route route="{{route}}" pattern="[[rootPath]]:page" data="{{routeData}}" tail="{{subroute}}">
      </app-route>
      <h2> Total amount : {{fare}} </h2> 


      <paper-radio-group id="mod" selected="" aria-labelledby="label1">
      <paper-radio-button name="PayTm">Paytm Mode</paper-radio-button> <br>
      <paper-radio-button name="UPI">UPI Mode</paper-radio-button>
    </paper-radio-group> <br>

    <paper-button raised class="custom indigo" on-click="_handleSummary">Submit</paper-button>
    `;
  }
  static get properties() {
    return {
      fare: {
        type: Number,
        value: sessionStorage.getItem("total")
      }
    };
  }
  _handleSummary(){

    this.set('route.path', './summary');
  }
}

window.customElements.define('transaction-type', TransactionType);
